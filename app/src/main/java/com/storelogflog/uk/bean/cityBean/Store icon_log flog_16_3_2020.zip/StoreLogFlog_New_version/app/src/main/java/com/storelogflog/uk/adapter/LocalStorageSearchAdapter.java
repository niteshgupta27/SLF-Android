package com.storelogflog.uk.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.FragmentActivity;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import com.storelogflog.uk.R;
import com.storelogflog.uk.bean.storageBean.Storage;
import com.storelogflog.uk.fragment.SearchStorageListFragmentDirections;

import java.util.List;

public class LocalStorageSearchAdapter extends RecyclerView.Adapter<LocalStorageSearchAdapter.StorageYardSearchHolder> {

    FragmentActivity activity;
    List<Storage> storageList;

    public LocalStorageSearchAdapter(FragmentActivity activity,List<Storage> storageList) {
        this.activity = activity;
        this.storageList=storageList;
    }

    @NonNull
    @Override
    public StorageYardSearchHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(activity).inflate(R.layout.item_storage_yards_view_more,parent,false);
        return new StorageYardSearchHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull StorageYardSearchHolder holder, int position) {

        final Storage storage=storageList.get(position);
        holder.txtStorageName.setText(""+storage.getName());
        holder.txtAddress1.setText(""+storage.getAddress1());
        holder.txtAddress2.setText(""+storage.getAddress2());
        holder.txtCity.setText(""+storage.getCity());
        holder.txtDescription.setText(""+storage.getShortDesp());

        holder.cardViewTop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                NavDirections directions= SearchStorageListFragmentDirections.actionSearchStorageListFragmentToStorageClaimFragment(storage);
                Navigation.findNavController(view).navigate(directions);
            }
        });

    }

    @Override
    public int getItemCount() {
        return storageList.size();
    }

    public class StorageYardSearchHolder extends RecyclerView.ViewHolder
    {
        private CardView cardViewTop;
        private AppCompatTextView txtStorageName;
        private AppCompatTextView txtAddress1;
        private AppCompatTextView txtAddress2;
        private AppCompatTextView txtCity;
        private AppCompatTextView txtDescription;
        private AppCompatTextView txtViewMore;
        private AppCompatImageView imgStorage;

        public StorageYardSearchHolder(@NonNull View itemView) {
            super(itemView);
            cardViewTop=itemView.findViewById(R.id.cardView);
            txtStorageName=itemView.findViewById(R.id.txt_storage_name);
            txtAddress1=itemView.findViewById(R.id.txt_address1);
            txtAddress2=itemView.findViewById(R.id.txt_address2);
            txtCity=itemView.findViewById(R.id.txt_city);
            txtDescription=itemView.findViewById(R.id.txt_des);
            txtViewMore=itemView.findViewById(R.id.txt_view_more);
            imgStorage=itemView.findViewById(R.id.img_storage);
        }
    }
}
