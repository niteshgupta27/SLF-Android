package com.storelogflog.uk.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatTextView;

import com.storelogflog.uk.R;
import com.storelogflog.uk.activity.HomeActivity;
import com.storelogflog.uk.callBackInterFace.DrawerLocker;


public class ItemNameFragment extends BaseFragment {

    private RelativeLayout rlSubmit;
    private AppCompatTextView txtAcceptOffer;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_item_name, container, false);
        initViews(view);
        initListeners();
        return view;
    }


    @Override
    public void initViews(View view) {

        rlSubmit=view.findViewById(R.id.rl_submit);
        txtAcceptOffer=view.findViewById(R.id.txt_accept_offer);
        hideShow();
        HomeActivity.txtToolBarTitle.setText("Item Name");
        ((DrawerLocker)getActivity()).setDrawerLocked(true);


    }

    @Override
    public void initListeners() {

        txtAcceptOffer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //Fragment fragment=new StorageClaimFragment();
               // Common.loadFragment(getActivity(),fragment,true);
            }
        });

        HomeActivity.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackClick();
            }
        });
    }

    public void hideShow()
    {
        HomeActivity.txtToolBarTitle.setVisibility(View.VISIBLE);
        HomeActivity.imgBack.setVisibility(View.VISIBLE);


        HomeActivity.imgSearch.setVisibility(View.GONE);
        HomeActivity.imgMenu.setVisibility(View.GONE);



    }
}
