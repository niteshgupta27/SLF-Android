package com.storelogflog.uk.activity;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.storelogflog.uk.R;
import com.storelogflog.uk.adapter.NotificationsAdapter;
import com.storelogflog.uk.adapter.StorageUnitAdapter;

public class NotificationActivity extends BaseActivity {

    private RecyclerView rvNotification;
    private NotificationsAdapter adapter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications);
        initViews();
        initListeners();
    }

    @Override
    public void initViews() {
        tvToolBarTitle=findViewById(R.id.txt_toolbar_title);
        rvNotification=findViewById(R.id.rv_notification);
        imgBack=findViewById(R.id.img_back);


        adapter = new NotificationsAdapter(NotificationActivity.this);
        rvNotification.setLayoutManager(new LinearLayoutManager(NotificationActivity.this, LinearLayoutManager.VERTICAL, false));
        rvNotification.setAdapter(adapter);


        hideShow();
        updateUi();
    }

    @Override
    public void initListeners() {

        imgBack.setOnClickListener(this);

    }

    @Override
    public void hideShow() {

        tvToolBarTitle.setVisibility(View.VISIBLE);
        imgBack.setVisibility(View.VISIBLE);

    }

    @Override
    public void updateUi() {

        tvToolBarTitle.setText("Notifications");
    }

    @Override
    public void onClick(View view) {

        switch (view.getId())
        {
            case R.id.img_back:
                finish();
        }
    }
}
