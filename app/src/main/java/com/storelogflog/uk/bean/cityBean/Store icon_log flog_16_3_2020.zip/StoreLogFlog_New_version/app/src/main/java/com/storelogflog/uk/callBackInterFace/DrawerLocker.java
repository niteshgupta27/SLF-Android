package com.storelogflog.uk.callBackInterFace;

public interface DrawerLocker {
    public void setDrawerLocked(boolean shouldLock);
}
