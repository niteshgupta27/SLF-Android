package com.storelogflog.uk.apputil;


/**
 * Created by Vijendra on 22-02-2020.
 */

public interface ServerCode {
    //constant server keys

    int REGISTER_CODE = 1;
    int LOGIN_CODE = 2;
    int FORGOT_PASSWORD_CODE = 3;
    int SOCIAL_LOGIN_CODE = 4;
    int STORAGE_LIST_CODE = 5;
    int STORAGE_INQUIRY_CODE = 6;
    int SEARCH_STORAGE_CODE = 7;
    int STORAGE_CLAIM_CODE = 8;
    int ALL_COUNTRY_CODE = 9;
    int SETTINGS_CODE = 10;
    int ALL_REGIONS_CODE = 11;
    int ALL_CITIES_CODE = 12;
    int GET_SETTINGS_CODE = 13;
    int UPDATE_ADDRESS_CODE = 14;
    int STORAGE_LEAD_CODE = 15;
    int ADD_STORAGE_CODE = 16;
    int ADD_ITEM_CODE = 17;


}
