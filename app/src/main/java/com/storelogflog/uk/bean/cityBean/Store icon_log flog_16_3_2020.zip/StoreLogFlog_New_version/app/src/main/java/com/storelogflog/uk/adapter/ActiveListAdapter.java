package com.storelogflog.uk.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.storelogflog.uk.R;
import com.storelogflog.uk.fragment.ItemNameFragment;
import com.storelogflog.uk.apputil.Common;

public class ActiveListAdapter extends RecyclerView.Adapter<ActiveListAdapter.ActiveListHolder> {

    FragmentActivity activity;

    public ActiveListAdapter(FragmentActivity activity) {
        this.activity = activity;
    }

    @NonNull
    @Override
    public ActiveListHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(activity).inflate(R.layout.item_actvie_list,parent,false);
        return new ActiveListHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ActiveListHolder holder, int position) {

          if(position%2==0)
          {
             holder.llOffersChild.setVisibility(View.VISIBLE);
             holder.llStatus.setVisibility(View.GONE);
          }
          else
          {
              holder.llStatus.setVisibility(View.VISIBLE);
              holder.llOffersChild.setVisibility(View.GONE);
          }

          holder.txtViewOffers.setOnClickListener(new View.OnClickListener() {
              @Override
              public void onClick(View view) {

                  Fragment fragment=new ItemNameFragment();
                  Common.loadFragment(activity,fragment,true,Common.ITEM_NAME_FRAGMENT);
              }
          });
    }

    @Override
    public int getItemCount() {
        return 10;
    }

    public class ActiveListHolder extends RecyclerView.ViewHolder
    {
          LinearLayout llOffersChild,llStatus;
          AppCompatTextView txtViewOffers;

        public ActiveListHolder(@NonNull View itemView) {
            super(itemView);
            llOffersChild=itemView.findViewById(R.id.ll_offers_child);
            llStatus=itemView.findViewById(R.id.ll_status);
            txtViewOffers=itemView.findViewById(R.id.txt_view_offers);
        }
    }
}
