package com.storelogflog.uk.apputil;


public final class Constants implements ServerCode {
    //api
    //host url domain name
    public static final String BASE_URL = "http://account.storelogflog.com";
    //api sub segment
    public static final String PATH = "api/";
    public static final String PLATFORM_IMAGE_PATH = BASE_URL + "assets/uploads/";
    public static final String IMAGE_PATH = PLATFORM_IMAGE_PATH;
    public static final String SECRET_KEY = "qhgCxWp2us";
    public static final String DEVICE_TYPE = "Android";


    public static final String API_REGISTER = "/api/register";
    public static final String API_ALL_COUNTRY = "/api/all-countries";
    public static final String API_ALL_REGIONS = "/api/all-regions";
    public static final String API_ALL_CITIES = "/api/all-cities";
    public static final String API_UPDATE_ADDRESS = "/api/update-address";
    public static final String API_FORGOT_PASSWORD = "/api/forgotpassword";
    public static final String API_LOGIN = "/api/login";
    public static final String API_SOCIAL_LOGIN = "/api/social-login";
    public static final String API_STORAGE_LIST = "/api/storage-list";
    public static final String API_STORAGE_INQUIRY = "/api/storage-inquiry";
    public static final String API_SEARCH_STORAGE = "/api/search-storage";
    public static final String API_STORAGE_CLAIM = "/api/storage-claim";
    public static final String API_SETTINGS = "/api/set-settings";
    public static final String API_GET_SETTINGS = "/api/get-settings";
    public static final String API_ALL_NOTIFICATIONS = "/api/all-notifications";
    public static final String API_STORAGE_LEAD = "/api/storage-lead";
    public static final String API_ADD_STORAGE = "/api/add-storage";
    public static final String API_ADD_ITEM = "/api/add-item";


    public static final String FROM="from";
    public static final String CONTACT_STORAGE_ACTIVITY="contact_storage";
    public static final String SEARCH_STORAGE_ACTIVITY="search_storage";
    public static final String DATA="data";
    public static final String FROM_CONTACT_STORAGE="contactStorage";
    public static final String FROM_STORAGE_CLAIM="storageClaim";
    public static final String FROM_STORAGE_LEAD="storageLead";
    public static final String FROM_PAYMENT_SCREEN="payment";


}
