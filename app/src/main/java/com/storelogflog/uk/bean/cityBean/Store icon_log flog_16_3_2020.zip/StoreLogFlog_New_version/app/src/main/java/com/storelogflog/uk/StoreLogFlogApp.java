package com.storelogflog.uk;

import android.app.Application;

import com.storelogflog.uk.apputil.PreferenceManger;
import com.storelogflog.uk.servers.PicassoManger;

public class StoreLogFlogApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        PreferenceManger.initPreference(getApplicationContext());
        PicassoManger.initPicassoInstance(getApplicationContext());

    }
}
