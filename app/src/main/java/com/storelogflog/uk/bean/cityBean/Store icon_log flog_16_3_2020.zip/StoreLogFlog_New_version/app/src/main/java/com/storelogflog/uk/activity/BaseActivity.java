package com.storelogflog.uk.activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatTextView;

import com.storelogflog.uk.apputil.Logger;
import com.storelogflog.uk.listeners.OnBackHandler;

import org.json.JSONException;
import org.json.JSONObject;

public  abstract class BaseActivity extends AppCompatActivity implements OnBackHandler,View.OnClickListener {

    String Tag = "BaseActivity";
    public AppCompatTextView tvToolBarTitle;
    public AppCompatImageView imgBack;
    public AppCompatImageView imgMenu;
    public AppCompatImageView imgSearch;
    public ProgressDialog progressDialog;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);


        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);
    }

    @Override
    public void onBackClick() {

        onBackPressed();
    }


    public abstract void initViews();
    public abstract void initListeners();
    public abstract void hideShow();
    public abstract void updateUi();

    public void showToast(String msg)
    {
        Toast.makeText(BaseActivity.this,msg,Toast.LENGTH_SHORT).show();
    }

    boolean showErrorMsg(EditText editText, String msg)
    {
        editText.setError(""+msg);
        editText.requestFocus();
        return false;
    }





    public void showLoading(String message) {
        if (!progressDialog.isShowing()) {
            progressDialog.setMessage(message);
            progressDialog.show();
        }
    }

    public void hideLoading() {
        if (progressDialog.isShowing())
            progressDialog.dismiss();
    }

    public String getStringFromJsonObj(JSONObject mJsonObject, String key) {
        String response = null;
        try {
            if (mJsonObject != null) {
                if (mJsonObject.has(key)) {
                    response = mJsonObject.getString(key);
                } else {
                    Logger.error(Tag, "Unable to find string obj key " + key + " in jsonObj " + mJsonObject.toString());
                }
            } else {
                Logger.error(Tag, "JsonObject is null");
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return response;
    }


    public int getIntFromJsonObj(JSONObject mJsonObject, String key) {
        int response = -1;
        try {
            if (mJsonObject != null) {
                if (mJsonObject.has(key)) {
                    response = mJsonObject.getInt(key);
                } else {
                    Logger.error(Tag, "Unable to find string obj key " + key + " in jsonObj " + mJsonObject.toString());
                }
            } else {
                Logger.error(Tag, "JsonObject is null");
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return response;
    }

}
