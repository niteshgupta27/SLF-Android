package com.storelogflog.uk.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.navigation.Navigation;
import androidx.navigation.ui.NavigationUI;

import com.android.volley.VolleyError;
import com.google.gson.Gson;
import com.storelogflog.uk.R;
import com.storelogflog.uk.activity.HomeActivity;
import com.storelogflog.uk.adapter.CityAdapter;
import com.storelogflog.uk.adapter.RegionAdapter2;
import com.storelogflog.uk.apiCall.AddItemApiCall;
import com.storelogflog.uk.apiCall.AddStorageApiCall;
import com.storelogflog.uk.apiCall.VolleyApiResponseString;
import com.storelogflog.uk.apputil.Constants;
import com.storelogflog.uk.apputil.Logger;
import com.storelogflog.uk.apputil.PrefKeys;
import com.storelogflog.uk.apputil.PreferenceManger;
import com.storelogflog.uk.apputil.Utility;
import com.storelogflog.uk.bean.cityBean.CityBean;
import com.storelogflog.uk.bean.regionBean.RegionBean;
import com.storelogflog.uk.callBackInterFace.DrawerLocker;

import org.json.JSONException;
import org.json.JSONObject;


public class AddItemFragment extends BaseFragment implements View.OnClickListener, VolleyApiResponseString {

    RelativeLayout rlAddItem;
    private AppCompatEditText editItemName;
    private AppCompatEditText editItemDescription;
    private AppCompatEditText editItemValue;
    private AppCompatEditText editLength;
    private AppCompatEditText editWidth;
    private AppCompatEditText editHeight;
    private AppCompatTextView txtInch;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_add_item, container, false);
        initViews(view);
        initListeners();
        return view;
    }


    @Override
    public void initViews(View view) {


        hideShow();
        HomeActivity.txtToolBarTitle.setText("Unit 115-Log");((DrawerLocker)getActivity()).setDrawerLocked(true);

         rlAddItem=view.findViewById(R.id.rl_add);
         editItemName =view.findViewById(R.id.edit_item_name);
         editItemDescription =view.findViewById(R.id.edit_item_description);
         editItemValue =view.findViewById(R.id.edit_item_value);
         editLength =view.findViewById(R.id.edit_length);
         editWidth =view.findViewById(R.id.edit_width);
         editHeight =view.findViewById(R.id.edit_height);
         txtInch =view.findViewById(R.id.edit_inch);

    }

    @Override
    public void initListeners() {

        rlAddItem.setOnClickListener(this);

        HomeActivity.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackClick();
            }
        });

     /*   rlAddItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

               // Fragment fragment=new StoreFragment();
              //  Common.loadFragment(getActivity(),fragment,false,Common.STORE_FRAGMENT);
            }
        });*/
    }

    public void hideShow()
    {
        HomeActivity.txtToolBarTitle.setVisibility(View.VISIBLE);
        HomeActivity.imgBack.setVisibility(View.VISIBLE);
        HomeActivity.imgSearch.setVisibility(View.GONE);
        HomeActivity.imgMenu.setVisibility(View.GONE);


    }

    @Override
    public void onClick(View view) {

        switch (view.getId())
        {
            case R.id.rl_add:
               // callAddItem();
                Navigation.findNavController(view).navigate(R.id.action_addItemFragment_to_photoFragment);
        }
    }



    public boolean isValidate()
    {
        if(editItemName.getText().toString().isEmpty())
        {
            return showErrorMsg(editItemName,"Item name can't be blank");
        }
        else if(editItemDescription.getText().toString().isEmpty())
        {
            return showErrorMsg(editItemDescription,"Description can't be blank");
        }
        else if(editItemValue.getText().toString().isEmpty())
        {
            return showErrorMsg(editItemValue,"Item value can't be blank");
        }

        else if(editLength.getText().toString().isEmpty())
        {
            return showErrorMsg(editItemValue,"Item length can't be blank");

        }
        else if(editWidth.getText().toString().isEmpty())
        {
            return showErrorMsg(editItemValue,"Item width can't be blank");

        }
        else if(editHeight.getText().toString().isEmpty())
        {
            return showErrorMsg(editItemValue,"Item height can't be blank");

        }
        else
        {
            return true;
        }

    }


    void callAddItem()
    {
        if(Utility.isInternetConnected(getActivity()))
        {

            if(isValidate())
            {
                try {
                    JSONObject jsonObjectPayload=new JSONObject();
                    jsonObjectPayload.put("storage","424");
                    jsonObjectPayload.put("unit","34");
                    jsonObjectPayload.put("name",editItemName.getText().toString());
                    jsonObjectPayload.put("description",editItemDescription.getText().toString());
                    jsonObjectPayload.put("length",editLength.getText().toString());
                    jsonObjectPayload.put("width",""+editWidth.getText().toString());
                    jsonObjectPayload.put("height",""+editHeight.getText().toString());
                    jsonObjectPayload.put("qty","4");
                    jsonObjectPayload.put("value",""+editItemValue.getText().toString());
                    jsonObjectPayload.put("location","era");
                    jsonObjectPayload.put("apikey", PreferenceManger.getPreferenceManger().getString(PrefKeys.APIKEY));
                    Logger.debug(TAG,jsonObjectPayload.toString());
                    String token=Utility.getJwtToken(jsonObjectPayload.toString());
                    showLoading("Loading...");
                    new AddItemApiCall(getActivity(),this,token, Constants.ADD_ITEM_CODE);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

        }
        else
        {
            showToast(getActivity(),"No Internet Connection");
        }
    }


    @Override
    public void onAPiResponseSuccess(String response, int code) {


        switch (code)
        {
            case Constants.ADD_ITEM_CODE:
                hideLoading();
                if(response!=null)
                {
                    String payload[]=response.split("\\.");
                    if (payload[1]!=null)
                    {
                        response=Utility.decoded( payload[1]);
                        try {
                            JSONObject jsonObject=new JSONObject(response);
                            Logger.debug(TAG,""+jsonObject.toString());
                            int result=getIntFromJsonObj(jsonObject,"result");
                            if(result==1)
                            {

                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
                break;




        }


    }

    @Override
    public void onAPiResponseError(VolleyError error, int code) {

        switch (code)
        {
            case Constants.ADD_ITEM_CODE:
                hideLoading();
                break;
        }
    }
}
