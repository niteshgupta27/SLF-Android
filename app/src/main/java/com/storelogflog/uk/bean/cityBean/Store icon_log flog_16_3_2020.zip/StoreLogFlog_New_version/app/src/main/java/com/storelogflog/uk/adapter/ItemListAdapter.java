package com.storelogflog.uk.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import com.storelogflog.uk.R;
import com.storelogflog.uk.fragment.ItemDetailsFragment;
import com.storelogflog.uk.apputil.Common;

public class ItemListAdapter extends RecyclerView.Adapter<ItemListAdapter.ItemListHolder> {

    FragmentActivity activity;

    public ItemListAdapter(FragmentActivity activity) {
        this.activity = activity;
    }

    @NonNull
    @Override
    public ItemListHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(activity).inflate(R.layout.item_bobs_storage,parent,false);
        return new ItemListHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ItemListHolder holder, int position) {

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Navigation.findNavController(view).navigate(R.id.action_logFragment_to_itemDetailsFragment);
            }
        });

    }

    @Override
    public int getItemCount() {
        return 10;
    }

    public class ItemListHolder extends RecyclerView.ViewHolder
    {
         RelativeLayout rlTop;

        public ItemListHolder(@NonNull View itemView) {
            super(itemView);

            rlTop =itemView.findViewById(R.id.rl_top);
        }
    }
}
