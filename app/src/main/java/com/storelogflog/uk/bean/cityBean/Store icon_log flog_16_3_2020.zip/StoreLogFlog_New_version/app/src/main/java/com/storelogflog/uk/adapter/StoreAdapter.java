package com.storelogflog.uk.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.storelogflog.uk.R;



public class StoreAdapter extends RecyclerView.Adapter<StoreAdapter.StoreHolder> {

    private FragmentActivity activity;
    public static int STORE=1;
    public static int LOG=2;
    public static int FLOG=3;
    private int from=-1;



    public StoreAdapter(FragmentActivity activity,int from) {
        this.activity = activity;
        this.from=from;
    }

    @NonNull
    @Override
    public StoreHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(activity).inflate(R.layout.item_storage_yards_comment,parent,false);
        return new StoreHolder(view);
    }




    @Override
    public void onBindViewHolder(@NonNull final StoreHolder holder, int position) {

        if (from==STORE)
        {
            holder.llLogFlogChat.setVisibility(View.VISIBLE);
        }
        else if(from==LOG)
        {
            holder.llLogFlogChat.setVisibility(View.GONE);
        }

        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (from==STORE)
                {
                    holder.llLogFlogChat.setVisibility(View.VISIBLE);
                }
                else if(from==LOG)
                {
                    holder.llLogFlogChat.setVisibility(View.GONE);
                }
            }
        });

    }

    @Override
    public int getItemCount() {
        return 2;
    }

    public class StoreHolder extends RecyclerView.ViewHolder
    {

        private CardView cardView;
        private LinearLayout llLogFlogChat;
        private AppCompatImageView imgStorage;
        private AppCompatTextView txtStorageTitle;
        private AppCompatTextView txtDescription;

        public StoreHolder(@NonNull View itemView) {
            super(itemView);

            cardView=itemView.findViewById(R.id.cardView);
            llLogFlogChat=itemView.findViewById(R.id.ll_chat_log_flog);
            txtDescription=itemView.findViewById(R.id.txt_des);
            imgStorage=itemView.findViewById(R.id.img_storage);
            txtStorageTitle=itemView.findViewById(R.id.txt_title);

        }
    }
}
