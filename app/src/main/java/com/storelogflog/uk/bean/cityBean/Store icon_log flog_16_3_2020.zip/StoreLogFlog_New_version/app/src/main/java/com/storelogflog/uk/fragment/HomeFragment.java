package com.storelogflog.uk.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import com.storelogflog.uk.R;
import com.storelogflog.uk.activity.HomeActivity;
import com.storelogflog.uk.callBackInterFace.DrawerLocker;

public class HomeFragment extends BaseFragment implements View.OnClickListener {

    private LinearLayout llContinue;
    private LinearLayout llFindStorage;
    private Fragment fragment;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.activity_home, container, false);
        initViews(view);
        initListeners();
        return view;
    }

    @Override
    public void initViews(View view) {

        llContinue=view.findViewById(R.id.ll_continue);
        llFindStorage=view.findViewById(R.id.ll_find_storage);

        HomeActivity.toolbar.setVisibility(View.VISIBLE);

        HomeActivity.txtToolBarTitle.setText("Welcone to Store Log Fog");

        hideShow();

        ((DrawerLocker)getActivity()).setDrawerLocked(false);


    }

    @Override
    public void initListeners() {

        llContinue.setOnClickListener(this);
        llFindStorage.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {

        switch (view.getId())
        {
            case R.id.ll_continue:
                Navigation.findNavController(view).navigate(R.id.action_home_to_storageSearchFragment);
                break;

            case R.id.ll_find_storage:
                Navigation.findNavController(view).navigate(R.id.action_home_to_storageListFragment);
                break;
        }
    }

    public void hideShow()
    {
        HomeActivity.imgMenu.setVisibility(View.VISIBLE);
        HomeActivity.txtToolBarTitle.setVisibility(View.VISIBLE);


        HomeActivity.imgSearch.setVisibility(View.GONE);
        HomeActivity.imgBack.setVisibility(View.GONE);

    }
}
