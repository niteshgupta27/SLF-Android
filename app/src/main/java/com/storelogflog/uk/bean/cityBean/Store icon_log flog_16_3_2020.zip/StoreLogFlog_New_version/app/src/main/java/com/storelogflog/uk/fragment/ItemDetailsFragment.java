package com.storelogflog.uk.fragment;

import android.content.Context;
import android.os.Bundle;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.storelogflog.uk.R;
import com.storelogflog.uk.activity.HomeActivity;


public class ItemDetailsFragment extends BaseFragment {

    private ViewPager viewPager;
    private LinearLayout dotsLayout;
    private CustomPagerAdapter customPagerAdapter;
    private int[] layouts;
    private TextView[] dots;
    int[] colorsActive;
    int[] colorsInactive;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_item_details, container, false);
        initViews(view);
        initListeners();
        return view;
    }


    @Override
    public void initViews(View view) {

        HomeActivity.txtToolBarTitle.setText("Sofa Set");

        viewPager=view.findViewById(R.id.view_pager);
        dotsLayout=view.findViewById(R.id.ll_dots);


        layouts= new int[3];
        dots= new TextView[3];
        colorsActive= new int[3];
        colorsInactive= new int[3];

        layouts= new int[]{R.layout.item_banner_image2, R.layout.item_banner_image, R.layout.item_banner_image2};

        customPagerAdapter = new CustomPagerAdapter();
        viewPager.setAdapter(customPagerAdapter);
        addBottomDots(0);


        hideShow();

    }

    @Override
    public void initListeners() {

        HomeActivity.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackClick();
            }
        });


        viewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

                addBottomDots(position);
            }

            @Override
            public void onPageSelected(int position) {

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    private void addBottomDots(int currentPage) {

        int[] colorsActive = getResources ().getIntArray (R.array.array_dot_active);
        int[] colorsInactive = getResources ().getIntArray (R.array.array_dot_inactive );

        dots = new TextView[layouts.length];


        dotsLayout.removeAllViews ();
        for (int i = 0; i < dots.length; i++) {
            dots[i] = new TextView (getActivity());
            dots[i].setText ( Html.fromHtml ( "&#8226;" ) );
            dots[i].setTextSize(35);
            dots[i].setTextColor(colorsInactive[currentPage] );
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams ( ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT );
            layoutParams.setMargins ( 6, 0, 6, 0 );
            dotsLayout.addView ( dots[i], layoutParams );
        }

        if (dots.length > 0)
            dots[currentPage].setTextColor (colorsActive[currentPage]);
    }


    public void hideShow()
    {
        HomeActivity.txtToolBarTitle.setVisibility(View.VISIBLE);

        HomeActivity.imgBack.setVisibility(View.VISIBLE);
        HomeActivity.imgMenu.setVisibility(View.GONE);
        HomeActivity.imgSearch.setVisibility(View.GONE);
    }


    public class CustomPagerAdapter extends PagerAdapter {
        private LayoutInflater layoutInflater;

        public CustomPagerAdapter() {
        }

        @Override
        public Object instantiateItem(ViewGroup container, int position) {
            layoutInflater = (LayoutInflater)getActivity().getSystemService ( Context.LAYOUT_INFLATER_SERVICE );


            View view = layoutInflater.inflate (layouts[position], container, false );
            container.addView ( view );
            AppCompatImageView imgBanner=view.findViewById(R.id.img_banner);
            return view;
        }

        @Override
        public int getCount() {
            return layouts.length;
        }

        @Override
        public boolean isViewFromObject(View view, Object obj) {
            return view == obj;
        }


        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            View view = (View) object;
            container.removeView ( view );
        }
    }

}
