package com.storelogflog.uk.listeners;

public interface OnBackHandler {
    void onBackClick();
}
