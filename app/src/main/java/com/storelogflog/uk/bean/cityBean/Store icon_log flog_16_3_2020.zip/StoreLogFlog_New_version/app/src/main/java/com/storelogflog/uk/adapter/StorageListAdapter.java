package com.storelogflog.uk.adapter;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import com.storelogflog.uk.R;
import com.storelogflog.uk.bean.storageBean.Storage;
import com.storelogflog.uk.fragment.StorageDetailsFragment;
import com.storelogflog.uk.apputil.Common;
import com.storelogflog.uk.fragment.StorageListFragmentDirections;

import java.util.List;

public class StorageListAdapter extends RecyclerView.Adapter<StorageListAdapter.StorageYardsHolder> {

    FragmentActivity activity;
    List<Storage>storageList;

    public StorageListAdapter(FragmentActivity activity, List<Storage> storageList) {
        this.activity = activity;
        this.storageList=storageList;
    }

    @NonNull
    @Override
    public StorageYardsHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(activity).inflate(R.layout.item_storage_yards,parent,false);
        return new StorageYardsHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull StorageYardsHolder holder, int position) {

        final Storage storage=storageList.get(position);
        holder.txtTitle.setText(""+storage.getName());
        holder.txtDescription.setText(""+storage.getShortDesp());

        holder.cardViewTop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                NavDirections directions=StorageListFragmentDirections.actionStorageListFragmentToStorageDetailsFragment(storage);
                Navigation.findNavController(view).navigate(directions);
            }
        });
    }

    @Override
    public int getItemCount() {
        return storageList.size();
    }

    public class StorageYardsHolder extends RecyclerView.ViewHolder
    {
        private CardView cardViewTop;
        private AppCompatTextView txtTitle;
        private AppCompatTextView txtDescription;
        private AppCompatTextView txtAvailabilityValue;
        private AppCompatTextView txtPriceValue;

        public StorageYardsHolder(@NonNull View itemView) {
            super(itemView);
            cardViewTop=itemView.findViewById(R.id.cardView);
            txtTitle=itemView.findViewById(R.id.txt_title);
            txtDescription=itemView.findViewById(R.id.txt_des);
            txtAvailabilityValue=itemView.findViewById(R.id.txt_availability_value);
            txtPriceValue=itemView.findViewById(R.id.txt_price_value);
        }
    }
}
