package com.storelogflog.uk.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.storelogflog.uk.R;
import com.storelogflog.uk.activity.HomeActivity;
import com.storelogflog.uk.apputil.Constants;
import com.storelogflog.uk.callBackInterFace.DrawerLocker;


public class PaymentFragment extends BaseFragment implements View.OnClickListener {

    private RelativeLayout rlMakePayment;



    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_payment, container, false);
        initViews(view);
        initListeners();
        return view;
    }


    @Override
    public void initViews(View view) {

        rlMakePayment=view.findViewById(R.id.rl_make_payment);

        hideShow();
        HomeActivity.txtToolBarTitle.setText("Payment");

        ((DrawerLocker)getActivity()).setDrawerLocked(false);


    }

    @Override
    public void initListeners() {

        rlMakePayment.setOnClickListener(this);
}

    public void hideShow()
    {
        HomeActivity.txtToolBarTitle.setVisibility(View.VISIBLE);
        HomeActivity.imgMenu.setVisibility(View.GONE);


        HomeActivity.imgSearch.setVisibility(View.GONE);
        HomeActivity.imgBack.setVisibility(View.VISIBLE);

    }

    @Override
    public void onClick(View view) {

        switch (view.getId())
        {
            case R.id.rl_make_payment:
                String message="Thank you for the request. Once your unit id is validated and approved, you can start logging the item.";
                NavDirections directions=PaymentFragmentDirections.actionPaymentFragmentToThankYouFragment(message,Constants.FROM_PAYMENT_SCREEN);
                Navigation.findNavController(getActivity(),R.id.main).navigate(directions);
                break;
        }
    }
}
