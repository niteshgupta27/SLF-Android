package com.storelogflog.uk.fragment;

import android.content.Context;
import android.os.Bundle;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatCheckBox;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.android.volley.VolleyError;
import com.storelogflog.uk.R;
import com.storelogflog.uk.activity.HomeActivity;
import com.storelogflog.uk.apiCall.StorageClaimApiCall;
import com.storelogflog.uk.apiCall.StorageInquiryApiCall;
import com.storelogflog.uk.apiCall.VolleyApiResponseString;
import com.storelogflog.uk.apputil.Constants;
import com.storelogflog.uk.apputil.Logger;
import com.storelogflog.uk.apputil.PrefKeys;
import com.storelogflog.uk.apputil.PreferenceManger;
import com.storelogflog.uk.apputil.Utility;
import com.storelogflog.uk.apputil.Validator;
import com.storelogflog.uk.bean.storageBean.Storage;
import com.storelogflog.uk.callBackInterFace.DrawerLocker;
import com.storelogflog.uk.dialog.TermsAndConditionDialog;
import com.storelogflog.uk.apputil.Common;

import org.json.JSONException;
import org.json.JSONObject;


public class StorageClaimFragment extends BaseFragment implements VolleyApiResponseString {

    private RelativeLayout rlSubmit;
    private AppCompatCheckBox cbTermsAndConditions;
    private AppCompatEditText editStorageUnit;
    private AppCompatEditText editStorageName;
    private AppCompatEditText editBillingEmail;
    private AppCompatTextView txtAddressLine1;
    private AppCompatTextView txtAddressLine2;
    private Storage storage;

    private ViewPager viewPager;
    private LinearLayout dotsLayout;
    private AppCompatImageView imgContactUs;
    private CustomPagerAdapter customPagerAdapter;
    private int[] layouts;
    private TextView[] dots;
    int[] colorsActive;
    int[] colorsInactive;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_storage_claim, container, false);
        initViews(view);
        initListeners();
        return view;
    }

    @Override
    public void initViews(View view) {

        viewPager=view.findViewById(R.id.view_pager);
        dotsLayout=view.findViewById(R.id.ll_dots);
        imgContactUs=view.findViewById(R.id.img_contact_us);

        rlSubmit=view.findViewById(R.id.rl_submit);
        cbTermsAndConditions=view.findViewById(R.id.cb_terms_and_conditions);
        editStorageUnit=view.findViewById(R.id.edit_storage_unit);
        editStorageName=view.findViewById(R.id.edit_storage_name);
        editBillingEmail=view.findViewById(R.id.edit_billing_email);
        txtAddressLine1=view.findViewById(R.id.txt_address_line1);
        txtAddressLine2=view.findViewById(R.id.txt_address_line2);




        layouts= new int[3];
        dots= new TextView[3];
        colorsActive= new int[3];
        colorsInactive= new int[3];

        layouts= new int[]{R.layout.item_banner_image, R.layout.item_banner_image2, R.layout.item_banner_image};

        customPagerAdapter = new CustomPagerAdapter();
        viewPager.setAdapter(customPagerAdapter);
        addBottomDots(0);


        hideShow();

        ((DrawerLocker)getActivity()).setDrawerLocked(true);


        if(getArguments()!=null)
        {
            storage=StorageDetailsFragmentArgs.fromBundle(getArguments()).getStorage();
            if(storage!=null)
            {
                updateUi(storage);
            }
        }


    }

    void  updateUi(Storage storage)
    {
        HomeActivity.txtToolBarTitle.setText(""+storage.getName());
        txtAddressLine1.setText(""+storage.getAddress1());
        txtAddressLine2.setText(""+storage.getAddress2());
    }

    @Override
    public void initListeners() {

        rlSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

               callStorageClaimApi();
            }
        });


        cbTermsAndConditions.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {

                new TermsAndConditionDialog(getActivity()) {
                    @Override
                    public void onClickIAgree() {

                        cbTermsAndConditions.setChecked(true);
                    }
                };
            }
        });

        HomeActivity.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackClick();
            }
        });



        viewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

                addBottomDots(position);
            }

            @Override
            public void onPageSelected(int position) {

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

    }

    public void hideShow()
    {
        HomeActivity.txtToolBarTitle.setVisibility(View.VISIBLE);
        HomeActivity.imgBack.setVisibility(View.VISIBLE);


        HomeActivity.imgSearch.setVisibility(View.GONE);
        HomeActivity.imgMenu.setVisibility(View.GONE);

    }

    private void addBottomDots(int currentPage) {

        int[] colorsActive = getResources ().getIntArray (R.array.array_dot_active);
        int[] colorsInactive = getResources ().getIntArray (R.array.array_dot_inactive );

        dots = new TextView[layouts.length];


        dotsLayout.removeAllViews ();
        for (int i = 0; i < dots.length; i++) {
            dots[i] = new TextView (getActivity());
            dots[i].setText ( Html.fromHtml ( "&#8226;" ) );
            dots[i].setTextSize(35);
            dots[i].setTextColor(colorsInactive[currentPage] );
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams ( ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT );
            layoutParams.setMargins ( 6, 0, 6, 0 );
            dotsLayout.addView ( dots[i], layoutParams );
        }

        if (dots.length > 0)
            dots[currentPage].setTextColor (colorsActive[currentPage]);
    }




    public class CustomPagerAdapter extends PagerAdapter {
        private LayoutInflater layoutInflater;

        public CustomPagerAdapter() {
        }

        @Override
        public Object instantiateItem(ViewGroup container, int position) {
            layoutInflater = (LayoutInflater)getActivity().getSystemService ( Context.LAYOUT_INFLATER_SERVICE );


            View view = layoutInflater.inflate (layouts[position], container, false );
            container.addView ( view );
            AppCompatImageView imgBanner=view.findViewById(R.id.img_banner);
            return view;
        }

        @Override
        public int getCount() {
            return layouts.length;
        }

        @Override
        public boolean isViewFromObject(View view, Object obj) {
            return view == obj;
        }


        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            View view = (View) object;
            container.removeView ( view );
        }
    }

    public boolean isValidate() {

        if (editStorageUnit.getText().toString().isEmpty()) {
            return showErrorMsg(editStorageUnit, "Storage unit can't be blank");
        }
        else if (editStorageName.getText().toString().isEmpty()) {
            return showErrorMsg(editStorageName, "Storage name can't be blank");
        }
        else if (editBillingEmail.getText().toString().isEmpty()) {
            return showErrorMsg(editBillingEmail, "Storage unit can't be blank");
        } else if (!Validator.isEmailValid(editBillingEmail.getText().toString())) {
            return showErrorMsg(editBillingEmail, "Invalid email");
        }
        else {
            return true;
        }

    }

    void callStorageClaimApi()
    {
        if(Utility.isInternetConnected(getActivity()))
        {
            if (isValidate())
            {
                try {
                    JSONObject jsonObjectPayload=new JSONObject();
                    jsonObjectPayload.put("apikey", PreferenceManger.getPreferenceManger().getString(PrefKeys.APIKEY));
                    jsonObjectPayload.put("storageid",storage.getID());
                    jsonObjectPayload.put("unitnumber",editStorageUnit.getText().toString());
                    jsonObjectPayload.put("name",editStorageName.getText().toString());
                    jsonObjectPayload.put("billingemail",editStorageName.getText().toString());

                    Logger.debug(TAG,jsonObjectPayload.toString());
                    String token=Utility.getJwtToken(jsonObjectPayload.toString());
                    new StorageClaimApiCall(getContext(),this,token, Constants.STORAGE_CLAIM_CODE);
                    showLoading("Loading...");

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
        else
        {
            showToast(getActivity(),"No Internet Connection");
        }
    }



    @Override
    public void onAPiResponseSuccess(String response, int code) {

        if(Constants.STORAGE_CLAIM_CODE==code)
        {
            hideLoading();
            if(response!=null)
            {
                String payload[]=response.split("\\.");
                if (payload[1]!=null)
                {
                    response=Utility.decoded( payload[1]);
                    try {
                        JSONObject jsonObject=new JSONObject(response);
                        Logger.debug(TAG,""+jsonObject.toString());
                        int result=getIntFromJsonObj(jsonObject,"result");
                        String message=getStringFromJsonObj(jsonObject,"Message");
                        if(result==1)
                        {
                            NavDirections directions=StorageClaimFragmentDirections.actionStorageClaimFragmentToThankYouFragment(message,Constants.FROM_STORAGE_CLAIM);
                            Navigation.findNavController(getActivity(),R.id.main).navigate(directions);
                        }
                        else
                        {
                            Utility.commonMsgDialog(getContext(), "" + message, true, null);

                        }


                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }


    }

    @Override
    public void onAPiResponseError(VolleyError error, int code) {

        if(Constants.STORAGE_CLAIM_CODE==code)
        {
            Logger.debug(TAG,""+Utility.returnErrorMsg(error,getContext()));
            hideLoading();
            showToast(getActivity(),Utility.returnErrorMsg(error,getContext()));
        }
    }

}
