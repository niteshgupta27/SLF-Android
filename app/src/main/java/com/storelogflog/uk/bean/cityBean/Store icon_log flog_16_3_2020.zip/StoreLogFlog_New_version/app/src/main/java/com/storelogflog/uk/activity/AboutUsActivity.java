package com.storelogflog.uk.activity;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.Nullable;

import com.storelogflog.uk.R;

public class AboutUsActivity extends BaseActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_title);
        initViews();
        initListeners();
    }

    @Override
    public void initViews() {
        tvToolBarTitle=findViewById(R.id.txt_toolbar_title);
        imgBack=findViewById(R.id.img_back);
        tvToolBarTitle.setText("Notification Details");
        hideShow();
    }

    @Override
    public void initListeners() {

        imgBack.setOnClickListener(this);
    }

    @Override




    public void hideShow() {

        tvToolBarTitle.setVisibility(View.VISIBLE);
        imgBack.setVisibility(View.VISIBLE);

    }

    @Override
    public void updateUi() {

    }

    @Override
    public void onClick(View view) {

        switch (view.getId())
        {
            case R.id.img_back:
                finish();
        }
    }
}
