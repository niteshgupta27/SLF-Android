package com.storelogflog.uk.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.storelogflog.uk.R;
import com.storelogflog.uk.activity.HomeActivity;


public class StorageSearchFragment extends BaseFragment implements View.OnClickListener {

    private AppCompatEditText editSearchYard;
    private AppCompatImageView imgSearchYard;
    private AppCompatTextView txtViewAllStorage;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_storage_search, container, false);
        initViews(view);
        initListeners();


        return view;
    }


    @Override
    public void initViews(View view) {

        editSearchYard=view.findViewById(R.id.edit_search_yard);
        imgSearchYard=view.findViewById(R.id.img_search_yard);
        txtViewAllStorage=view.findViewById(R.id.txt_all_storage);
        HomeActivity.toolbar.setVisibility(View.GONE);

    }

    @Override
    public void initListeners() {

        imgSearchYard.setOnClickListener(this);
        txtViewAllStorage.setOnClickListener(this);

    }


    @Override
    public void onClick(View view) {

        NavDirections directions = null;
        switch (view.getId()) {

            case R.id.img_search_yard:

                directions = StorageSearchFragmentDirections.actionStorageSearchFragmentToSearchStorageListFragment(editSearchYard.getText().toString());
                Navigation.findNavController(view).navigate(directions);
                /*if(!editSearchYard.getText().toString().equals(""))
                {
                    NavDirections directions=StorageSearchFragmentDirections.actionStorageSearchFragmentToSearchStorageListFragment(editSearchYard.getText().toString());
                    Navigation.findNavController(view).navigate(directions);
                }
                else
                {
                    showToast(getActivity(),"Please enter value first");
                }*/
                break;
            case R.id.txt_all_storage:
                directions = StorageSearchFragmentDirections.actionStorageSearchFragmentToSearchStorageListFragment("");
                Navigation.findNavController(view).navigate(directions);


        }

    }
}
