package com.storelogflog.uk.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import com.storelogflog.uk.R;
import com.storelogflog.uk.activity.HomeActivity;
import com.storelogflog.uk.apputil.Common;

public class DashBoardFragment extends BaseFragment implements View.OnClickListener {

    private Fragment fragment;
    private CardView cardViewStroe;
    private CardView cardViewLog;
    private CardView cardViewFlog;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_dashboard, container, false);
        initViews(view);
        initListeners();

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void initViews(View view) {

        cardViewStroe= view.findViewById(R.id.cardView_store);
        cardViewLog= view.findViewById(R.id.cardview_log);
        cardViewFlog= view.findViewById(R.id.cardview_flog);
        HomeActivity.txtToolBarTitle.setText("Dashboard");
        hideShow();
    }

    @Override
    public void initListeners() {

        cardViewStroe.setOnClickListener(this);
        cardViewLog.setOnClickListener(this);
        cardViewFlog.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.cardView_store:
                Navigation.findNavController(view).navigate(R.id.action_dashBoardFragment_to_storeFragment);
                break;
            case R.id.cardview_log:
                Navigation.findNavController(view).navigate(R.id.action_dashBoardFragment_to_logFragment);

                break;
            case R.id.cardview_flog:
                Navigation.findNavController(view).navigate(R.id.action_dashBoardFragment_to_flogFragment);
                break;
        }

    }

    public void hideShow()
    {
        HomeActivity.imgMenu.setVisibility(View.VISIBLE);
        HomeActivity.imgSearch.setVisibility(View.VISIBLE);
        HomeActivity.txtToolBarTitle.setVisibility(View.VISIBLE);
        HomeActivity.toolbar.setVisibility(View.VISIBLE);
        HomeActivity.imgBack.setVisibility(View.GONE);
    }
}
