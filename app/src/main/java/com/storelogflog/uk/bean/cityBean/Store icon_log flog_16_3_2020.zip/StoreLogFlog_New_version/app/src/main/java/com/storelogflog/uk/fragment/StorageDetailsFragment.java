package com.storelogflog.uk.fragment;

import android.content.Context;
import android.os.Bundle;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;
import androidx.navigation.ui.NavigationUI;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.storelogflog.uk.R;

import com.storelogflog.uk.activity.HomeActivity;
import com.storelogflog.uk.adapter.StorageUnitAdapter;
import com.storelogflog.uk.apputil.Common;
import com.storelogflog.uk.bean.storageBean.Storage;


public class StorageDetailsFragment extends BaseFragment {

    private RecyclerView rvStorageUnit;
    private StorageUnitAdapter adapter;
    private ViewPager viewPager;
    private LinearLayout dotsLayout;
    private AppCompatImageView imgContactUs;
    private CustomPagerAdapter customPagerAdapter;
    private int[] layouts;
    private TextView[] dots;
    int[] colorsActive;
    int[] colorsInactive;
    private AppCompatTextView txtTitle;
    private AppCompatTextView txtAddressLine1;
    private AppCompatTextView txtAddressLine2;
    private AppCompatTextView txtDescription;
    Storage storage;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_storage_details, container, false);
        initViews(view);
        initListeners();
        return view;
    }


    @Override
    public void initViews(View view) {



        viewPager=view.findViewById(R.id.view_pager);
        dotsLayout=view.findViewById(R.id.ll_dots);
        rvStorageUnit=view.findViewById(R.id.rv_storage_unit);
        imgContactUs=view.findViewById(R.id.img_contact_us);
        txtTitle=view.findViewById(R.id.txt_title);
        txtAddressLine1=view.findViewById(R.id.txt_address_line1);
        txtAddressLine2=view.findViewById(R.id.txt_address_line2);
        txtDescription=view.findViewById(R.id.txt_description);

        layouts= new int[3];
        dots= new TextView[3];
        colorsActive= new int[3];
        colorsInactive= new int[3];

        layouts= new int[]{R.layout.item_banner_image, R.layout.item_banner_image2, R.layout.item_banner_image};

        customPagerAdapter = new CustomPagerAdapter();
        viewPager.setAdapter(customPagerAdapter);
        addBottomDots(0);


        if (getArguments() != null) {
            storage = StorageDetailsFragmentArgs.fromBundle(getArguments()).getStorage();
            if (storage != null) {
                updateUi(storage);

            }
        }



        adapter = new StorageUnitAdapter(getActivity());
        rvStorageUnit.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        rvStorageUnit.setAdapter(adapter);

        hideShow();

    }

    void updateUi(Storage storage)
    {
        HomeActivity.txtToolBarTitle.setText(""+storage.getName());
        txtTitle.setText(""+storage.getName());
        txtAddressLine1.setText(""+storage.getAddress1());
        txtAddressLine2.setText(""+storage.getAddress2());
        txtDescription.setText(""+storage.getLongDesp());
    }

    @Override
    public void initListeners() {

        HomeActivity.imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackClick();
            }
        });

        imgContactUs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                NavDirections directions=StorageDetailsFragmentDirections.actionStorageDetailsFragmentToContactStorageFragment(storage);
                Navigation.findNavController(view).navigate(directions);
            }
        });


        viewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

                addBottomDots(position);
            }

            @Override
            public void onPageSelected(int position) {

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    private void addBottomDots(int currentPage) {

        int[] colorsActive = getResources ().getIntArray (R.array.array_dot_active);
        int[] colorsInactive = getResources ().getIntArray (R.array.array_dot_inactive );

        dots = new TextView[layouts.length];


        dotsLayout.removeAllViews ();
        for (int i = 0; i < dots.length; i++) {
            dots[i] = new TextView (getActivity());
            dots[i].setText ( Html.fromHtml ( "&#8226;" ) );
            dots[i].setTextSize(35);
            dots[i].setTextColor(colorsInactive[currentPage] );
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams ( ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT );
            layoutParams.setMargins ( 6, 0, 6, 0 );
            dotsLayout.addView ( dots[i], layoutParams );
        }

        if (dots.length > 0)
            dots[currentPage].setTextColor (colorsActive[currentPage]);
    }


    public void hideShow()
    {
        HomeActivity.txtToolBarTitle.setVisibility(View.VISIBLE);

        HomeActivity.imgBack.setVisibility(View.VISIBLE);
        HomeActivity.imgMenu.setVisibility(View.GONE);
        HomeActivity.imgSearch.setVisibility(View.GONE);
    }


    public class CustomPagerAdapter extends PagerAdapter {
        private LayoutInflater layoutInflater;

        public CustomPagerAdapter() {
        }

        @Override
        public Object instantiateItem(ViewGroup container, int position) {
            layoutInflater = (LayoutInflater)getActivity().getSystemService ( Context.LAYOUT_INFLATER_SERVICE );


            View view = layoutInflater.inflate (layouts[position], container, false );
            container.addView ( view );
            AppCompatImageView imgBanner=view.findViewById(R.id.img_banner);
            return view;
        }

        @Override
        public int getCount() {
            return layouts.length;
        }

        @Override
        public boolean isViewFromObject(View view, Object obj) {
            return view == obj;
        }


        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            View view = (View) object;
            container.removeView ( view );
        }
    }

}
