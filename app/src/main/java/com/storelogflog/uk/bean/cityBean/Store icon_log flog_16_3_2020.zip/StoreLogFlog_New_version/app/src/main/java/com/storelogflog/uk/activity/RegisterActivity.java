package com.storelogflog.uk.activity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.appcompat.widget.AppCompatTextView;
import com.android.volley.VolleyError;
import com.storelogflog.uk.R;
import com.storelogflog.uk.adapter.RegionAdapter;
import com.storelogflog.uk.apiCall.RegisterApiCall;
import com.storelogflog.uk.apiCall.VolleyApiResponseString;
import com.storelogflog.uk.apputil.Constants;
import com.storelogflog.uk.apputil.Logger;
import com.storelogflog.uk.apputil.Utility;
import com.storelogflog.uk.apputil.Validator;
import com.storelogflog.uk.bean.RegionBean;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;



public class RegisterActivity extends BaseActivity implements VolleyApiResponseString,View.OnClickListener {

    String TAG = this.getClass().getSimpleName();
    private AppCompatEditText editFirstName;
    private AppCompatEditText editLastName;
    private AppCompatEditText editPhoneNumber;
    private AppCompatEditText editEmail;
    private AppCompatEditText editPassword;
    private AppCompatTextView txtRegion;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        initViews();
        initListeners();
    }

    @Override
    public void initViews() {

        editFirstName=findViewById(R.id.edit_first_name);
        editLastName=findViewById(R.id.edit_last_name);
        editPhoneNumber=findViewById(R.id.edit_mobile);
        editEmail=findViewById(R.id.edit_email);
        editPassword=findViewById(R.id.edit_password);
        txtRegion=findViewById(R.id.txt_region);

    }

    @Override
    public void initListeners() {

        findViewById(R.id.txt_register).setOnClickListener(this);
        findViewById(R.id.ll_signin).setOnClickListener(this);
        txtRegion.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
         switch (view.getId())
         {
             case R.id.txt_register:
                 register();
                 break;

             case R.id.ll_signin:
                 startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
                 finish();
                 break;

             case R.id.txt_region:
                 regionDialog();
                 break;
         }
    }

    @Override
    public void onAPiResponseSuccess(String response, int code) {

        if(Constants.REGISTER_CODE==code)
        {
            hideLoading();
            if(response!=null)
            {
                String payload[]=response.split("\\.");
                if (payload[1]!=null)
                {
                    response=Utility.decoded( payload[1]);
                    try {
                        JSONObject jsonObject=new JSONObject(response);
                        Logger.debug(TAG,""+jsonObject.toString());
                        int result=getIntFromJsonObj(jsonObject,"result");
                        String message=getStringFromJsonObj(jsonObject,"message");
                        if(result==1)
                        {
                            Utility.commonMsgDialog(RegisterActivity.this, "" + message, false, new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {

                                    startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
                                    finish();
                                }
                            });

                        }
                        else
                        {
                            Utility.commonMsgDialog(RegisterActivity.this, "" + message, true, null);

                        }


                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }

    }

    @Override
    public void onAPiResponseError(VolleyError error, int code) {

        if(Constants.REGISTER_CODE==code)
        {
            Logger.debug(TAG,""+Utility.returnErrorMsg(error,RegisterActivity.this));
            hideLoading();
            showToast(Utility.returnErrorMsg(error,RegisterActivity.this));
        }

    }



    @Override
    public void hideShow() {

    }

    @Override
    public void updateUi() {

    }


    public void register()
    {
        if(Utility.isInternetConnected(RegisterActivity.this))
        {
            if (isValidate())
            {
                try {
                    JSONObject jsonObjectPayload=new JSONObject();
                    jsonObjectPayload.put("firstname",editFirstName.getText().toString());
                    jsonObjectPayload.put("lastname",editLastName.getText().toString());
                    jsonObjectPayload.put("email",editEmail.getText().toString());
                    jsonObjectPayload.put("phonenumber",editPhoneNumber.getText().toString());
                    jsonObjectPayload.put("password",editPassword.getText().toString());
                    jsonObjectPayload.put("IP","142.142.25.25");
                    jsonObjectPayload.put("region",txtRegion.getText().toString());
                    jsonObjectPayload.put("fcmtoken","3dsad8fdf8fdf8fffdf");


                    Logger.debug(TAG,jsonObjectPayload.toString());
                    String token=Utility.getJwtToken(jsonObjectPayload.toString());
                    new RegisterApiCall(RegisterActivity.this,this,token, Constants.REGISTER_CODE);
                    showLoading("Register...");

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
        else
        {
            showToast("No Internet Connection");
        }

    }

    public boolean isValidate()
    {
        if(editFirstName.getText().toString().isEmpty())
        {
            return showErrorMsg(editFirstName,"First name can't be blank");
        }
        else if(editLastName.getText().toString().isEmpty())
        {
            return showErrorMsg(editLastName,"Last name can't be blank");
        }
        else if(editPhoneNumber.getText().toString().isEmpty())
        {
            return showErrorMsg(editPhoneNumber,"Mobile number can't be blank");
        }
        else if(!Validator.isValidMobileNo(editPhoneNumber.getText().toString()))
        {
            return showErrorMsg(editPhoneNumber,"Invalid Mobile Number");
        }
        else if(editEmail.getText().toString().isEmpty())
        {
            return showErrorMsg(editEmail,"Email can't be blank");
        }
        else if(!Validator.isEmailValid(editEmail.getText().toString()))
        {
            return showErrorMsg(editEmail,"Invalid email");
        }
        else if(txtRegion.getText().toString().isEmpty() || txtRegion.getText().toString().equals("Select your region *"))
        {
             showToast("Region can't be blank");
             return false;
        }

        else if(editPassword.getText().toString().isEmpty())
        {
            return showErrorMsg(editPassword,"Password can't be blank");
        }
        else if(editPassword.getText().toString().length()<6)
        {
            return showErrorMsg(editPassword,"Password can't be less than 6 digits");
        }
        else
        {
            return true;
        }

    }


    void regionDialog()
    {
        final Dialog dialog = new Dialog(RegisterActivity.this);

        dialog.setContentView(R.layout.dialog_region_popup);
        dialog.setCancelable(true);
        ListView lvRegion=dialog.findViewById(R.id.lv_region);

        final ArrayList<RegionBean> regionList=getRegionList();

        if(regionList!=null) {
            if (regionList.size() > 0) {
                RegionAdapter adapter = new RegionAdapter(regionList, RegisterActivity.this);
                lvRegion.setAdapter(adapter);
            }
        }


        lvRegion.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                RegionBean  model=regionList.get(position);
                txtRegion.setText(model.getName());
                dialog.dismiss();


            }
        });

        dialog.show();


    }



    public ArrayList<RegionBean> getRegionList()
    {

        ArrayList<RegionBean> regionList=new ArrayList();
        regionList.add(new RegionBean("Select your region *","0"));
        regionList.add(new RegionBean("South East","1"));
        regionList.add(new RegionBean("London","2"));
        regionList.add(new RegionBean("North West","3"));
        regionList.add(new RegionBean("East of England","4"));
        regionList.add(new RegionBean("West Midlands","5"));
        regionList.add(new RegionBean("South West","6"));
        regionList.add(new RegionBean("Yorkshire and the Humber","7"));
        regionList.add(new RegionBean("East Midlands","8"));
        regionList.add(new RegionBean("North East","9"));

        return regionList;
    }

}
