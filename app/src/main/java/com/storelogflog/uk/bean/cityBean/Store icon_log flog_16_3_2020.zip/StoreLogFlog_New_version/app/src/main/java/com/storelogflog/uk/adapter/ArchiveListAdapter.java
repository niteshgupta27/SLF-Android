package com.storelogflog.uk.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.storelogflog.uk.R;

public class ArchiveListAdapter extends RecyclerView.Adapter<ArchiveListAdapter.ActiveListHolder> {

    FragmentActivity activity;

    public ArchiveListAdapter(FragmentActivity activity) {
        this.activity = activity;
    }

    @NonNull
    @Override
    public ActiveListHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(activity).inflate(R.layout.item_archive_list,parent,false);
        return new ActiveListHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ActiveListHolder holder, int position) {


    }

    @Override
    public int getItemCount() {
        return 10;
    }

    public class ActiveListHolder extends RecyclerView.ViewHolder
    {

        public ActiveListHolder(@NonNull View itemView) {
            super(itemView);

        }
    }
}
