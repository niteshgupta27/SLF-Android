package com.storelogflog.uk.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.navigation.Navigation;
import com.storelogflog.uk.R;
import com.storelogflog.uk.activity.HomeActivity;
import com.storelogflog.uk.apputil.Constants;
import com.storelogflog.uk.callBackInterFace.DrawerLocker;



public class ThankYouFragment extends BaseFragment implements View.OnClickListener {

    private LinearLayout llContinue;
    private AppCompatTextView txtUserMessage;
    private String from;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_thank_you_req, container, false);
        initViews(view);
        initListeners();
        return view;
    }


    @Override
    public void initViews(View view) {

        llContinue=view.findViewById(R.id.ll_continue);
        txtUserMessage=view.findViewById(R.id.txt_user_msg);

        hideShow();
        HomeActivity.txtToolBarTitle.setText("Storage");

        ((DrawerLocker)getActivity()).setDrawerLocked(false);

        if (getArguments() != null) {
            String message = ThankYouFragmentArgs.fromBundle(getArguments()).getMessage();
            from=ThankYouFragmentArgs.fromBundle(getArguments()).getFrom();
            txtUserMessage.setText(""+message);
        }
    }

    @Override
    public void initListeners() {

     llContinue.setOnClickListener(this);
    }

    public void hideShow()
    {
        HomeActivity.txtToolBarTitle.setVisibility(View.VISIBLE);
        HomeActivity.imgMenu.setVisibility(View.VISIBLE);


        HomeActivity.imgSearch.setVisibility(View.GONE);
        HomeActivity.imgBack.setVisibility(View.GONE);



    }

    @Override
    public void onClick(View view) {

        switch (view.getId())
        {
            case R.id.ll_continue:
                if (from.equals(Constants.FROM_CONTACT_STORAGE))
                {
                    Navigation.findNavController(view).navigate(R.id.action_thankYouFragment_to_storageListFragment);
                }
                else if(from.equals(Constants.FROM_STORAGE_CLAIM))
                {
                    Navigation.findNavController(view).navigate(R.id.action_thankYouFragment_to_dashBoardFragment);
                }
                else if(from.equals(Constants.FROM_STORAGE_LEAD))
                {
                    Navigation.findNavController(view).navigate(R.id.action_thankYouFragment_to_dashBoardFragment);
                }
                else if(from.equals(Constants.FROM_PAYMENT_SCREEN))
                {
                    Navigation.findNavController(view).navigate(R.id.action_thankYouFragment_to_storeFragment);
                }

                break;


        }
    }
}
