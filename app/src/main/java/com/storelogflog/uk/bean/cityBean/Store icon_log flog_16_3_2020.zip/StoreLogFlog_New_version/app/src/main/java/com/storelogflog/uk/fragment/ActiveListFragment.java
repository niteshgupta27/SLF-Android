package com.storelogflog.uk.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.storelogflog.uk.R;
import com.storelogflog.uk.activity.HomeActivity;
import com.storelogflog.uk.adapter.ActiveListAdapter;
import com.storelogflog.uk.callBackInterFace.DrawerLocker;
import com.storelogflog.uk.apputil.Common;

public class ActiveListFragment extends BaseFragment {

    private RecyclerView rvItemList;
    private ActiveListAdapter adapter;
    private FloatingActionButton fab;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.active_item_list, container, false);
        initViews(view);
        initListeners();
        return view;
    }


    @Override
    public void initViews(View view) {
        rvItemList=view.findViewById(R.id.rv_item_list);
        fab=view.findViewById(R.id.fab_add);


        hideShow();
      //  HomeActivity.txtToolBarTitle.setText("Storage Yard's");

        adapter = new ActiveListAdapter(getActivity());
        rvItemList.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        rvItemList.setAdapter(adapter);

        ((DrawerLocker)getActivity()).setDrawerLocked(false);
    }

    @Override
    public void initListeners() {

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Fragment fragment=new AddAuctionItemFragment();
                Common.loadFragment(getActivity(),fragment,true,Common.ITEM_DETAILS_FRAGMENT);
            }
        });
    }

    public void hideShow()
    {
        HomeActivity.toolbar.setVisibility(View.VISIBLE);
    }
}
