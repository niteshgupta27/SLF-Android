package com.storelogflog.uk.adapter;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.storelogflog.uk.R;
import com.storelogflog.uk.activity.AboutUsActivity;

public class NotificationsAdapter extends RecyclerView.Adapter<NotificationsAdapter.NotificationHolder> {

    FragmentActivity activity;

    public NotificationsAdapter(FragmentActivity activity) {
        this.activity = activity;
    }

    @NonNull
    @Override
    public NotificationHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(activity).inflate(R.layout.item_notifications,parent,false);
        return new NotificationHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull NotificationHolder holder, int position) {

        holder.rlTop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                activity.startActivity(new Intent(activity, AboutUsActivity.class));
            }
        });

    }

    @Override
    public int getItemCount() {
        return 2;
    }

    public class NotificationHolder extends RecyclerView.ViewHolder
    {

        RelativeLayout rlTop;


        public NotificationHolder(@NonNull View itemView) {
            super(itemView);

           rlTop= itemView.findViewById(R.id.rl_top);


        }
    }
}
