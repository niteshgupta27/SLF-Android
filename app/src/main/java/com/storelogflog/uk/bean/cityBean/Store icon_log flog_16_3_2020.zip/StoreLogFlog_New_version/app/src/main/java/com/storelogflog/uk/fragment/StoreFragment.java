package com.storelogflog.uk.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.github.clans.fab.FloatingActionButton;
import com.storelogflog.uk.R;
import com.storelogflog.uk.activity.HomeActivity;
import com.storelogflog.uk.adapter.StoreAdapter;
import com.storelogflog.uk.apputil.Logger;
import com.storelogflog.uk.callBackInterFace.DrawerLocker;
import com.storelogflog.uk.apputil.Common;


public class StoreFragment extends BaseFragment implements View.OnClickListener {

    private StoreAdapter adapter;
    private RecyclerView rvStore;
    private FloatingActionButton fbAddOwn;
    private FloatingActionButton fbAddAnother;
    private Fragment fragment;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_store, container, false);
        initViews(view);
        initListeners();
        return view;
    }


    @Override
    public void initViews(View view) {

        rvStore=view.findViewById(R.id.rv_store);
        fbAddOwn=view.findViewById(R.id.fb_add_own);
        fbAddAnother=view.findViewById(R.id.fb_add_another);
        hideShow();
        HomeActivity.txtToolBarTitle.setText("Storage Yard's");

        ((DrawerLocker)getActivity()).setDrawerLocked(false);

      /*  if (getArguments()!=null)
        {
            int from=StoreFragmentArgs.fromBundle(getArguments()).getFrom();
            Logger.error("from",""+from);
        }*/

        adapter = new StoreAdapter(getActivity(),StoreAdapter.STORE);
        rvStore.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        rvStore.setAdapter(adapter);

    }

    @Override
    public void initListeners() {

        fbAddAnother.setOnClickListener(this);
        fbAddOwn.setOnClickListener(this);

    }

    public void hideShow()
    {
        HomeActivity.txtToolBarTitle.setVisibility(View.VISIBLE);
        HomeActivity.imgMenu.setVisibility(View.VISIBLE);


        HomeActivity.imgSearch.setVisibility(View.GONE);
        HomeActivity.imgBack.setVisibility(View.GONE);



    }

    @Override
    public void onClick(View view) {

        switch (view.getId())
        {
            case R.id.fb_add_another:
                Navigation.findNavController(view).navigate(R.id.action_storeFragment_to_home);
                break;
            case R.id.fb_add_own:
                Navigation.findNavController(view).navigate(R.id.action_storeFragment_to_addPaidStorageFragment);
                break;
        }
    }
}
