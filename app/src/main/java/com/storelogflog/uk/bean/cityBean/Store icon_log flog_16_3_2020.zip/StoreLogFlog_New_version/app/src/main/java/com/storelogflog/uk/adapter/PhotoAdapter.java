package com.storelogflog.uk.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.storelogflog.uk.R;

public class PhotoAdapter extends RecyclerView.Adapter<PhotoAdapter.ActiveListHolder> {

    FragmentActivity activity;

    public PhotoAdapter(FragmentActivity activity) {
        this.activity = activity;
    }

    @NonNull
    @Override
    public ActiveListHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(activity).inflate(R.layout.item_photo,parent,false);
        return new ActiveListHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ActiveListHolder holder, int position) {


    }

    @Override
    public int getItemCount() {
        return 10;
    }

    public class ActiveListHolder extends RecyclerView.ViewHolder
    {

        private AppCompatImageView imgPhoto;
        private AppCompatTextView txtRemove;
        private LinearLayout llTop;

        public ActiveListHolder(@NonNull View itemView) {
            super(itemView);

            imgPhoto=itemView.findViewById(R.id.img_photo);
            txtRemove=itemView.findViewById(R.id.txt_remove);
            llTop=itemView.findViewById(R.id.ll_top);

        }
    }
}
