package com.storelogflog.uk.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.VolleyError;
import com.google.gson.Gson;
import com.storelogflog.uk.R;
import com.storelogflog.uk.activity.HomeActivity;
import com.storelogflog.uk.adapter.StorageListAdapter;
import com.storelogflog.uk.apiCall.StorageListApiCall;
import com.storelogflog.uk.apiCall.VolleyApiResponseString;
import com.storelogflog.uk.apputil.Constants;
import com.storelogflog.uk.apputil.Logger;
import com.storelogflog.uk.apputil.PrefKeys;
import com.storelogflog.uk.apputil.PreferenceManger;
import com.storelogflog.uk.apputil.Utility;
import com.storelogflog.uk.bean.storageBean.StorageBean;
import com.storelogflog.uk.callBackInterFace.DrawerLocker;

import org.json.JSONException;
import org.json.JSONObject;

public class StorageListFragment extends BaseFragment implements VolleyApiResponseString {

    String TAG = this.getClass().getSimpleName();
    private RecyclerView rvStorageYards;
    private StorageListAdapter adapter;
    private AppCompatTextView txtErrorMsg;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_storage_list, container, false);
        initViews(view);
        initListeners();
        return view;
    }


    @Override
    public void initViews(View view) {
        rvStorageYards=view.findViewById(R.id.rv_storage_yards);
        txtErrorMsg=view.findViewById(R.id.txt_error_msg);


        hideShow();
        HomeActivity.txtToolBarTitle.setText("Storage Yard's");


        rvStorageYards.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));

        ((DrawerLocker)getActivity()).setDrawerLocked(false);


        JSONObject jsonObjectPayload = null;
        try {
            jsonObjectPayload = new JSONObject();
            jsonObjectPayload.put("apikey",PreferenceManger.getPreferenceManger().getString(PrefKeys.APIKEY));
        } catch (JSONException e) {
            e.printStackTrace();
        }

        showLoading("Store List...");
        String token = Utility.getJwtToken(jsonObjectPayload.toString());
        new StorageListApiCall(getActivity(), this, token, Constants.STORAGE_LIST_CODE);

    }

    @Override
    public void initListeners() {

    }

    public void hideShow()
    {
        HomeActivity.txtToolBarTitle.setVisibility(View.VISIBLE);
        HomeActivity.imgSearch.setVisibility(View.VISIBLE);
        HomeActivity.imgMenu.setVisibility(View.VISIBLE);


        HomeActivity.imgBack.setVisibility(View.GONE);
    }

    @Override
    public void onAPiResponseSuccess(String response, int code) {

        hideLoading();
        switch (code)
        {
            case Constants.STORAGE_LIST_CODE:
                if (response != null) {

                String payload[] = response.split("\\.");
                if (payload[1] != null) {
                    response = Utility.decoded(payload[1]);
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        Logger.debug(TAG, "" + jsonObject.toString());
                        int result = getIntFromJsonObj(jsonObject, "result");
                        if (result == 1) {
                            StorageBean storageBean= new Gson().fromJson(response, StorageBean.class);
                            if (storageBean!=null && storageBean.getStorage()!=null && storageBean.getStorage().size()>0)
                            {
                                adapter = new StorageListAdapter(getActivity(),storageBean.getStorage());
                                rvStorageYards.setAdapter(adapter);
                                rvStorageYards.setVisibility(View.VISIBLE);
                                txtErrorMsg.setVisibility(View.GONE);
                            }
                            else
                            {
                                rvStorageYards.setVisibility(View.GONE);
                                txtErrorMsg.setVisibility(View.VISIBLE);
                            }
                        } else {

                            rvStorageYards.setVisibility(View.GONE);
                            txtErrorMsg.setVisibility(View.VISIBLE);

                        }

                        //showToast(message);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
                break;

        }

    }

    @Override
    public void onAPiResponseError(VolleyError error, int code) {

        hideLoading();
        switch (code)
        {
            case Constants.STORAGE_LIST_CODE:
                rvStorageYards.setVisibility(View.GONE);
                txtErrorMsg.setVisibility(View.VISIBLE);
                txtErrorMsg.setText(""+Utility.returnErrorMsg(error,getActivity()));
                break;


        }
    }
}
