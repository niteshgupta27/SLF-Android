package com.storelogflog.uk.activity;

import android.content.Intent;
import android.os.Bundle;

import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBarDrawerToggle;
import com.google.android.material.navigation.NavigationView;
import com.storelogflog.uk.R;
import com.storelogflog.uk.adapter.StoreAdapter;
import com.storelogflog.uk.apputil.Common;
import com.storelogflog.uk.apputil.PrefKeys;
import com.storelogflog.uk.apputil.PreferenceManger;
import com.storelogflog.uk.callBackInterFace.DrawerLocker;
import com.storelogflog.uk.fragment.HomeFragment;

import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.NavDestination;
import androidx.navigation.NavGraph;
import androidx.navigation.NavInflater;
import androidx.navigation.NavOptions;
import androidx.navigation.Navigation;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;


public class HomeActivity extends BaseActivity  implements NavigationView.OnNavigationItemSelectedListener, View.OnClickListener, DrawerLocker {

    private DrawerLayout drawerLayout;
    private LinearLayout llHeader;
    private Fragment fragment;
    private Bundle bundle;
    private AppCompatImageView imgUser;
    public static AppCompatImageView imgMenu;
    public static AppCompatImageView imgBack;
    public static AppCompatImageView imgSearch;
    public static AppCompatTextView txtToolBarTitle;
    public  AppCompatTextView txtUserName;
    public  AppCompatTextView txtEmail;
    ActionBarDrawerToggle actionBarDrawerToggle;

    private NavController navController;
    private AppBarConfiguration appBarConfiguration;
    public static Toolbar toolbar;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_navigation_drawer);
        initViews();
        updateUi();
        initListeners();
    }

    @Override
    protected void onResume() {
        super.onResume();

      /*  Intent intent=getIntent();
        if(intent!=null)
        {
            if(intent.hasExtra(Constants.FROM))
            {
                if(intent.getStringExtra(Constants.FROM).equals(Constants.SEARCH_STORAGE_ACTIVITY))
                {
                    String data=intent.getStringExtra(Constants.DATA);
                    fragment=new SearchStorageListFragment();
                    bundle=new Bundle();
                    bundle.putString(Constants.DATA,data);
                    fragment.setArguments(bundle);
                    Common.loadFragment(HomeActivity.this,fragment,true,Common.STORAGE_YARD_VIEW_MORE_FRAGMENT);

                }
            }
        }*/


    }

    public void initViews() {

        imgMenu = findViewById(R.id.img_menu);
        imgBack = findViewById(R.id.img_back);
        imgSearch = findViewById(R.id.img_search);
        toolbar = findViewById(R.id.toolbar);
        txtToolBarTitle = findViewById(R.id.txt_toolbar_title);
        drawerLayout = findViewById(R.id.drawer_layout);

        final NavigationView navigationView = findViewById(R.id.nav_view);
        View headerView = navigationView.getHeaderView(0);
        llHeader = headerView.findViewById(R.id.ll_header);
        imgUser = headerView.findViewById(R.id.img_user);
        txtUserName = headerView.findViewById(R.id.txt_user_name);
        txtEmail = headerView.findViewById(R.id.txt_email);

        actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout,null,R.string.navigation_drawer_open, R.string.navigation_drawer_close);

        actionBarDrawerToggle.syncState();
        drawerLayout.addDrawerListener(actionBarDrawerToggle);


        navigationView.setNavigationItemSelectedListener(this);



        navController = Navigation.findNavController(this,R.id.main);
        appBarConfiguration = new AppBarConfiguration.Builder(new int[]{R.id.dashBoardFragment,R.id.storeFragment})
                .setDrawerLayout(drawerLayout)
                .build();

//        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);


        Common.loadFragment(HomeActivity.this,new HomeFragment(),false,Common.HOME_FRAGMENT);

       navController.addOnDestinationChangedListener(new NavController.OnDestinationChangedListener() {
           @Override
           public void onDestinationChanged(@NonNull NavController controller, @NonNull NavDestination destination, @Nullable Bundle arguments) {

               switch (destination.getId())
               {
                   case R.id.dashBoardFragment:



                       break;
                   case R.id.storeFragment:

                      /* NavHostFragment navHostFragment = (NavHostFragment) getSupportFragmentManager().findFragmentById(R.id.main);  // Hostfragment
                       NavInflater inflater = navHostFragment.getNavController().getNavInflater();
                       NavGraph graph = inflater.inflate(R.navigation.mobile_navigation);

                       graph.setStartDestination(R.id.storeFragment);

                       navHostFragment.getNavController().setGraph(graph);
                       // navHostFragment.getNavController().getGraph().setDefaultArguments(getIntent().getExtras());
                       // NavigationUI.setupWithNavController(navigationView, navHostFragment.getNavController());
                       Bundle bundle=new Bundle();
                       bundle.putInt("from", StoreAdapter.STORE);
                       navHostFragment.getNavController().navigate(R.id.storeFragment,bundle);*/

                       break;
                   case R.id.logFragment:
                     /*  NavHostFragment navHostFragment2 = (NavHostFragment) getSupportFragmentManager().findFragmentById(R.id.main);  // Hostfragment
                       NavInflater inflater2 = navHostFragment2.getNavController().getNavInflater();
                       NavGraph graph2 = inflater2.inflate(R.navigation.mobile_navigation);

                       graph2.setStartDestination(R.id.storeFragment);

                       navHostFragment2.getNavController().setGraph(graph2);
                       // navHostFragment.getNavController().getGraph().setDefaultArguments(getIntent().getExtras());
                      // NavigationUI.setupWithNavController(navigationView, navHostFragment.getNavController());
                       Bundle bundle2=new Bundle();
                       bundle2.putInt("from", StoreAdapter.LOG);
                       navHostFragment2.getNavController().navigate(R.id.storeFragment,bundle2);*/

                       break;
                   case R.id.flogFragment:
                       // fragment=new FlogFragment();
                       //Common.loadFragment(HomeActivity.this,fragment,true,Common.FLOG_FRAGMENT);
                       break;
                   case R.id.storageListFragment:
                       // fragment=new StorageListFragment();
                       // Common.loadFragment(HomeActivity.this,fragment,true,Common.STORAGE_YARD_FRAGMENT);
                       break;
                   case R.id.notificationActivity:
                       startActivity(new Intent(HomeActivity.this,NotificationActivity.class));
                       break;
                   case R.id.settingFragment:
                       break;
                   case R.id.nav_aboutus:
                       //  startActivity(new Intent(HomeActivity.this,AboutUsActivity.class));
                       break;
                   case R.id.contactUsFragment:
                       break;
                   case R.id.nav_logout:
                       logout();
                       break;
               }

           }
       });


    }


    public void initListeners() {

        imgMenu.setOnClickListener(this);
        imgBack.setOnClickListener(this);
        llHeader.setOnClickListener(this);
    }

    @Override
    public void hideShow() {

    }

    @Override
    public void updateUi() {

       // txtUserName.setText(""+PreferenceManger.getPreferenceManger().getString(PrefKeys.USERFIRSTNAME));
        txtEmail.setText(""+PreferenceManger.getPreferenceManger().getString(PrefKeys.EMAIL));

    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

        switch (menuItem.getItemId()) {

            case R.id.dashBoardFragment:

               // Common.loadFragment(HomeActivity.this,new DashBoardFragment(),true,Common.DASHBOARD_FRAGMENT);
                break;
           case R.id.storeFragment:
               break;
            case R.id.logFragment:
                break;
            case R.id.flogFragment:
               // fragment=new FlogFragment();
                //Common.loadFragment(HomeActivity.this,fragment,true,Common.FLOG_FRAGMENT);
                break;
            case R.id.storageListFragment:
               // fragment=new StorageListFragment();
               // Common.loadFragment(HomeActivity.this,fragment,true,Common.STORAGE_YARD_FRAGMENT);
                break;
            case R.id.notificationActivity:
                startActivity(new Intent(HomeActivity.this,NotificationActivity.class));
                break;
            case R.id.settingFragment:
               // startActivity(new Intent(HomeActivity.this,SettingActivity.class));
                break;
            case R.id.nav_aboutus:
              //  startActivity(new Intent(HomeActivity.this,AboutUsActivity.class));
                break;
            case R.id.contactUsFragment:
                break;
            case R.id.nav_logout:
                logout();
                break;

        }

        drawerLayout.closeDrawers();
        return false;

    }

    void logout()
    {
        PreferenceManger.getPreferenceManger().setBoolean(PrefKeys.ISLOGIN,false);
        //startActivity(new Intent(HomeActivity.this,LoginActivity.class));
       Intent intent=new Intent();
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|
                Intent.FLAG_ACTIVITY_CLEAR_TASK |
                Intent.FLAG_ACTIVITY_NEW_TASK);
        this.finish();

        NavOptions navOptions = new NavOptions.Builder()
                .setPopUpTo(R.id.home, true)
                .build();


        navController.navigate(R.id.action_home_to_nav_logout);

    }


    @Override
    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.img_menu:
                drawerLayout.openDrawer(Gravity.LEFT);
                break;
            case R.id.ll_header:
                startActivity(new Intent(HomeActivity.this,ProfileActivity.class));
                drawerLayout.closeDrawers();
                break;
        }
    }

    @Override
    public void setDrawerLocked(boolean shouldLock) {

        if(shouldLock){
            drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED);
        }else{
            drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED);
        }
    }


    @Override
    public boolean onSupportNavigateUp() {
        return NavigationUI.navigateUp(navController,appBarConfiguration );
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}
