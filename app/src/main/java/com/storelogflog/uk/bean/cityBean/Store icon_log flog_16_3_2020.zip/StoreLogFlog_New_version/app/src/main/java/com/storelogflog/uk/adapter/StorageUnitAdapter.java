package com.storelogflog.uk.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.storelogflog.uk.R;

public class StorageUnitAdapter extends RecyclerView.Adapter<StorageUnitAdapter.StorageUnitHolder> {

    FragmentActivity activity;

    public StorageUnitAdapter(FragmentActivity activity) {
        this.activity = activity;
    }

    @NonNull
    @Override
    public StorageUnitHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(activity).inflate(R.layout.item_storage_unit,parent,false);
        return new StorageUnitHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull StorageUnitHolder holder, int position) {

         if(position==1)
             holder.txtHorizontalLine.setVisibility(View.GONE);

    }

    @Override
    public int getItemCount() {
        return 2;
    }

    public class StorageUnitHolder extends RecyclerView.ViewHolder
    {

        private AppCompatTextView txtHorizontalLine;

        public StorageUnitHolder(@NonNull View itemView) {
            super(itemView);

            txtHorizontalLine=itemView.findViewById(R.id.txt_horizontal_line);

        }
    }
}
