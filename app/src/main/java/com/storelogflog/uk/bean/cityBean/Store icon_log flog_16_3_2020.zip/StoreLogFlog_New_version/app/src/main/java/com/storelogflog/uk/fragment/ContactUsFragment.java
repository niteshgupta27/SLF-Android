package com.storelogflog.uk.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.navigation.Navigation;

import com.storelogflog.uk.R;
import com.storelogflog.uk.activity.HomeActivity;
import com.storelogflog.uk.apputil.Constants;
import com.storelogflog.uk.callBackInterFace.DrawerLocker;


public class ContactUsFragment extends BaseFragment implements View.OnClickListener {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_contact_us, container, false);
        initViews(view);
        initListeners();
        return view;
    }


    @Override
    public void initViews(View view) {

        HomeActivity.txtToolBarTitle.setText("Contact Us");
        hideShow();

    }

    @Override
    public void initListeners() {

     HomeActivity.imgBack.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View view) {

             onBackClick();
         }
     });
    }

    public void hideShow()
    {
        HomeActivity.txtToolBarTitle.setVisibility(View.VISIBLE);
        HomeActivity.imgMenu.setVisibility(View.GONE);
        HomeActivity.imgSearch.setVisibility(View.GONE);
        HomeActivity.imgBack.setVisibility(View.VISIBLE);

    }

    @Override
    public void onClick(View view) {


    }
}
