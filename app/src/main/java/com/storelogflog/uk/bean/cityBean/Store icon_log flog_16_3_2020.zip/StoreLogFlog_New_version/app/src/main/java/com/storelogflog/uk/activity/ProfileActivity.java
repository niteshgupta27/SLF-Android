package com.storelogflog.uk.activity;

import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListView;

import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatTextView;

import com.android.volley.VolleyError;
import com.google.gson.Gson;
import com.storelogflog.uk.R;
import com.storelogflog.uk.adapter.CityAdapter;
import com.storelogflog.uk.adapter.CountryAdapter;
import com.storelogflog.uk.adapter.RegionAdapter;
import com.storelogflog.uk.adapter.RegionAdapter2;
import com.storelogflog.uk.apiCall.CityApiCall;
import com.storelogflog.uk.apiCall.RegionApiCall;
import com.storelogflog.uk.apiCall.UpdateAddressApiCall;
import com.storelogflog.uk.apiCall.VolleyApiResponseString;
import com.storelogflog.uk.apputil.Constants;
import com.storelogflog.uk.apputil.Logger;
import com.storelogflog.uk.apputil.PrefKeys;
import com.storelogflog.uk.apputil.PreferenceManger;
import com.storelogflog.uk.apputil.Utility;

import com.storelogflog.uk.bean.cityBean.CityBean;
import com.storelogflog.uk.bean.regionBean.RegionBean;
import com.storelogflog.uk.bean.countryBean.CountryBean;
import com.storelogflog.uk.bean.login.LoginBean;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ProfileActivity extends BaseActivity implements View.OnClickListener, VolleyApiResponseString {

    String TAG = this.getClass().getSimpleName();
    private AppCompatImageView imgBack,imgEdit;
    private AppCompatTextView txtToolBarTitle,txtEditProfile;
    private AppCompatEditText editName,editEmail,editPhone,editAddress1,editAddress2;
    private AppCompatTextView txtCountry,txtRegion,txtCity;
    private LinearLayout llCountry;
    private LinearLayout llRegion;
    private LinearLayout llCity;
    private  RegionBean  regionBean;
    private CityBean cityBean;
    private int cityId=0;
    private int regionId=0;
    private int countryId=0;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        initViews();
        initListeners();
    }

    @Override
    public void initViews() {

        imgBack=findViewById(R.id.img_back);
        txtToolBarTitle=findViewById(R.id.txt_toolbar_title);
        editName=findViewById(R.id.edit_name);
        editEmail=findViewById(R.id.edit_email);
        editPhone=findViewById(R.id.edit_phone);
        editAddress1=findViewById(R.id.edit_address1);
        editAddress2=findViewById(R.id.edit_address2);
        imgEdit=findViewById(R.id.img_edit);
        txtEditProfile=findViewById(R.id.txt_edit_profile);
        txtCity=findViewById(R.id.txt_city);
        txtCountry=findViewById(R.id.txt_country);
        txtRegion=findViewById(R.id.txt_region);
        llCountry=findViewById(R.id.ll_country);
        llRegion=findViewById(R.id.ll_region);
        llCity=findViewById(R.id.ll_city);

        editName.setEnabled(false);
        editEmail.setEnabled(false);
        editPhone.setEnabled(false);
        editAddress1.setEnabled(false);
        editAddress2.setEnabled(false);
        txtCity.setEnabled(false);
        txtCountry.setEnabled(false);
        txtRegion.setEnabled(false);


        hideShow();


        LoginBean loginBean=PreferenceManger.getPreferenceManger().getObject(PrefKeys.USER_INFO, LoginBean.class);


        updateUi(loginBean);


    }


    public void initListeners()
    {
        imgBack.setOnClickListener(this);
        imgEdit.setOnClickListener(this);
        txtEditProfile.setOnClickListener(this);
        llCountry.setOnClickListener(this);
        llRegion.setOnClickListener(this);
        llCity.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.img_back:
                onBackPressed();
                break;

            case R.id.img_edit:
                editTable();
                break;

            case R.id.txt_edit_profile:
               // nonEditTable();
                callUpdateApi();
                break;
            case R.id.ll_country:
                 countryDialog();
                 break;
            case R.id.ll_region:
                callAllRegionApi(countryId);
                break;
            case R.id.ll_city:
                callAllCityApi(regionId);
                break;


        }
    }

    @Override
    public void hideShow()
    {
        imgBack.setVisibility(View.VISIBLE);
        txtToolBarTitle.setVisibility(View.VISIBLE);
        imgEdit.setVisibility(View.VISIBLE);
    }

    @Override
    public void updateUi() {

    }


    public void updateUi(LoginBean loginBean)
    {
        txtToolBarTitle.setText("Profile");

        editName.setText(""+loginBean.getFirstname()+" "+loginBean.getLastname());
        editEmail.setText(""+loginBean.getEmail());
        editEmail.setText(""+loginBean.getPhone());
        editEmail.setText(""+loginBean.getAddress1());
        editEmail.setText(""+loginBean.getAddress2());


    }

    public void editTable()
    {
        editName.setEnabled(true);
        editEmail.setEnabled(true);
        editPhone.setEnabled(true);
        editAddress1.setEnabled(true);
        editAddress2.setEnabled(true);
        txtCity.setEnabled(true);
        txtCountry.setEnabled(true);
        txtRegion.setEnabled(true);

        txtEditProfile.setVisibility(View.VISIBLE);
        imgEdit.setVisibility(View.GONE);


    }

    public void nonEditTable()
    {
        editName.setEnabled(false);
        editEmail.setEnabled(false);
        editPhone.setEnabled(false);
        editAddress1.setEnabled(false);
        editAddress2.setEnabled(false);
        txtCity.setEnabled(false);
        txtCountry.setEnabled(false);
        txtRegion.setEnabled(false);
        txtEditProfile.setVisibility(View.GONE);
        imgEdit.setVisibility(View.VISIBLE);
    }

    @Override
    public void onAPiResponseSuccess(String response, int code) {

        hideLoading();

        switch (code)
        {
            case Constants.ALL_COUNTRY_CODE:
                if(response!=null)
                {
                    String payload[]=response.split("\\.");
                    if (payload[1]!=null)
                    {
                        response=Utility.decoded( payload[1]);
                        try {
                            JSONObject jsonObject=new JSONObject(response);
                            Logger.debug(TAG,""+jsonObject.toString());
                            int result=getIntFromJsonObj(jsonObject,"result");
                            String message=getStringFromJsonObj(jsonObject,"Message");
                            if(result==1)
                            {
                               CountryBean countryBean=new Gson().fromJson(response, CountryBean.class);
                            }
                            else
                            {

                            }


                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
                break;

            case Constants.ALL_REGIONS_CODE:
                if(response!=null)
                {
                    String payload[]=response.split("\\.");
                    if (payload[1]!=null)
                    {
                        response=Utility.decoded( payload[1]);
                        try {
                            JSONObject jsonObject=new JSONObject(response);
                            Logger.debug(TAG,""+jsonObject.toString());
                            int result=getIntFromJsonObj(jsonObject,"result");
                            if(result==1)
                            {
                                regionBean=new Gson().fromJson(response, RegionBean.class);
                                regionDialog();
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
                break;

            case Constants.ALL_CITIES_CODE:
                if(response!=null)
                {
                    String payload[]=response.split("\\.");
                    if (payload[1]!=null)
                    {
                        response=Utility.decoded( payload[1]);
                        try {
                            JSONObject jsonObject=new JSONObject(response);
                            Logger.debug(TAG,""+jsonObject.toString());
                            int result=getIntFromJsonObj(jsonObject,"result");
                            if(result==1)
                            {

                                cityBean=new Gson().fromJson(response, CityBean.class);
                                cityDialog();
                            }


                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
                break;


            case Constants.UPDATE_ADDRESS_CODE:
                hideLoading();
                if(response!=null)
                {
                    String payload[]=response.split("\\.");
                    if (payload[1]!=null)
                    {
                        response=Utility.decoded( payload[1]);
                        try {
                            JSONObject jsonObject=new JSONObject(response);
                            Logger.debug(TAG,""+jsonObject.toString());
                            int result=getIntFromJsonObj(jsonObject,"result");
                            String message=getStringFromJsonObj(jsonObject,"message");
                            if(result==1)
                            {
                               showToast(message);

                            }


                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
                break;



        }



    }

    @Override
    public void onAPiResponseError(VolleyError error, int code) {


        switch (code) {
            case Constants.ALL_COUNTRY_CODE:
                break;
            case Constants.ALL_REGIONS_CODE:
                break;
            case Constants.ALL_CITIES_CODE:
                break;
        }


    }


    void callAllRegionApi(int id)
    {
        if(Utility.isInternetConnected(ProfileActivity.this))
        {
            try {
                JSONObject jsonObjectPayload=new JSONObject();
                jsonObjectPayload.put("country",""+id);
                Logger.debug(TAG,jsonObjectPayload.toString());
                String token=Utility.getJwtToken(jsonObjectPayload.toString());
                new RegionApiCall(ProfileActivity.this,this,token, Constants.ALL_REGIONS_CODE);

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        else
        {
            showToast("No Internet Connection");
        }
    }



    void callAllCityApi(int id)
    {
        if(Utility.isInternetConnected(ProfileActivity.this))
        {
            try {
                JSONObject jsonObjectPayload=new JSONObject();
                jsonObjectPayload.put("region",""+id);
                Logger.debug(TAG,jsonObjectPayload.toString());
                String token=Utility.getJwtToken(jsonObjectPayload.toString());
                new CityApiCall(ProfileActivity.this,this,token, Constants.ALL_CITIES_CODE);

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        else
        {
            showToast("No Internet Connection");
        }
    }


    void callUpdateApi()
    {
        if(Utility.isInternetConnected(ProfileActivity.this))
        {
            try {
                JSONObject jsonObjectPayload=new JSONObject();
                jsonObjectPayload.put("address1",editAddress1.getText().toString());
                jsonObjectPayload.put("address2",editAddress2.getText().toString());
                jsonObjectPayload.put("region",""+regionId);
                jsonObjectPayload.put("country",""+countryId);
                jsonObjectPayload.put("city",""+cityId);
                jsonObjectPayload.put("apikey",PreferenceManger.getPreferenceManger().getString(PrefKeys.APIKEY));
                Logger.debug(TAG,jsonObjectPayload.toString());
                String token=Utility.getJwtToken(jsonObjectPayload.toString());
                showLoading("Loading...");
                new UpdateAddressApiCall(ProfileActivity.this,this,token, Constants.UPDATE_ADDRESS_CODE);

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        else
        {
            showToast("No Internet Connection");
        }
    }

    void countryDialog()
    {
        final Dialog dialog = new Dialog(ProfileActivity.this);

        dialog.setContentView(R.layout.dialog_sppiner_popup);
        dialog.setCancelable(true);
        ListView listView=dialog.findViewById(R.id.listview);
       // AppCompatTextView txtTitle=dialog.findViewById(R.id.txt_title);
       // txtTitle.setText("Select Country");

        final CountryBean countryBean=PreferenceManger.getPreferenceManger().getObject(PrefKeys.COUNTRY_LIST,CountryBean.class);

        if(countryBean!=null) {
            if (countryBean.getCountries().size() > 0) {

                CountryAdapter adapter = new CountryAdapter(countryBean.getCountries(),ProfileActivity.this);
                listView.setAdapter(adapter);
            }
        }


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                String countryName=countryBean.getCountries().get(position).getName();
                txtCountry.setText(countryName);

                 countryId=countryBean.getCountries().get(position).getID();

                txtRegion.setText("Select Region");
                txtCity.setText("Select City");

                dialog.dismiss();




            }
        });

        dialog.show();


    }


    void regionDialog()
    {
        final Dialog dialog = new Dialog(ProfileActivity.this);

        dialog.setContentView(R.layout.dialog_sppiner_popup);
        dialog.setCancelable(true);
        ListView listView=dialog.findViewById(R.id.listview);
        // AppCompatTextView txtTitle=dialog.findViewById(R.id.txt_title);
        // txtTitle.setText("Select Country");
        if(regionBean!=null) {
            if (regionBean.getRegion()!=null && regionBean.getRegion().size() > 0) {

                RegionAdapter2 adapter = new RegionAdapter2(regionBean.getRegion(),ProfileActivity.this);
                listView.setAdapter(adapter);
            }
        }


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                txtRegion.setText(regionBean.getRegion().get(position).getName());
                txtCity.setText("Select City");
                regionId=regionBean.getRegion().get(position).getID();


                dialog.dismiss();

            }
        });

        dialog.show();


    }


    void cityDialog()
    {
        final Dialog dialog = new Dialog(ProfileActivity.this);

        dialog.setContentView(R.layout.dialog_sppiner_popup);
        dialog.setCancelable(true);
        ListView listView=dialog.findViewById(R.id.listview);
        // AppCompatTextView txtTitle=dialog.findViewById(R.id.txt_title);
        // txtTitle.setText("Select Country");


        if(cityBean!=null && cityBean.getCities().size()>0) {

            CityAdapter adapter = new CityAdapter(cityBean.getCities(),ProfileActivity.this);
            listView.setAdapter(adapter);
        }


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {


                txtCity.setText(cityBean.getCities().get(position).getName());
                cityId=cityBean.getCities().get(position).getID();


                dialog.dismiss();


            }
        });

        dialog.show();


    }

}


