package com.storelogflog.uk.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.storelogflog.uk.R;
import com.storelogflog.uk.activity.HomeActivity;
import com.storelogflog.uk.activity.LoginActivity;
import com.storelogflog.uk.activity.SplashActivity;
import com.storelogflog.uk.apputil.Common;
import com.storelogflog.uk.apputil.PrefKeys;
import com.storelogflog.uk.apputil.PreferenceManger;
import com.storelogflog.uk.callBackInterFace.DrawerLocker;


public class SplashFragment extends BaseFragment{
    private LinearLayout llContinue;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.activity_splash, container, false);
        initViews(view);
        initListeners();
        return view;
    }


    @Override
    public void initViews(View view) {

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (PreferenceManger.getPreferenceManger().getBoolean(PrefKeys.ISLOGIN))
                {
                    //startActivity(new Intent(SplashActivity.this, HomeActivity.class));
                }
                else
                {
                   // startActivity(new Intent(SplashActivity.this, LoginActivity.class));
                }



            }
        }, 1000);

    }

    @Override
    public void initListeners() {


    }



}
